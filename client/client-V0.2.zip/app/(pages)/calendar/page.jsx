import LeaveCalendar from "@/app/components/Calender";

export default function Calender() {
    return (
        <LeaveCalendar />
    )
}